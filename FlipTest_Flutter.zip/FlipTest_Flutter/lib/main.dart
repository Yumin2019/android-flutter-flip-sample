import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    duration: const Duration(milliseconds: 2000),
    vsync: this,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Padding(padding: EdgeInsets.only(top: 200)),
          const Text("Flutter", style: TextStyle(fontSize: 32)),
          Center(
            child: AnimatedBuilder(
              animation: _controller,
              child: Image.asset(
                'assets/test.jpg',
                width: 200,
                height: 200,
              ),
              builder: (BuildContext context, Widget? child) {
                // print("     value ${_controller.drive(CurveTween(curve: Curves.ease)).value}");
                // print("just value ${_controller.value}");
                return Transform(
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.005) // col = 2, row = 3 & 0.003 = depth perception in the Z direction
                    ..rotateY( _controller.drive(CurveTween(curve: Curves.easeInOut)).value * 2.0 * pi), // _controller.drive(CurveTween(curve: Curves.linear))
                  alignment: Alignment.center,
                  child: child,
                );
              },
            ),
          ),

          const Padding(padding: EdgeInsets.only(top: 50)),

          TextButton(
            child: const Text("회전하기"),
            onPressed: () {
              _controller.forward(from: 0.0);
          },),
        ],
      ),
    );
  }
}
